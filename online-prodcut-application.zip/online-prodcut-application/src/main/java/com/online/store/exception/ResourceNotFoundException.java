package com.online.store.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RuntimeException {
    private String productId;

    public ResourceNotFoundException(String productId) {
        super(String.format("%s not found with %s : '%s'", productId));
        this.productId = productId;
    }

    public String getProdctId() {
        return productId;
    }


}
