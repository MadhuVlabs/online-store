package com.online.store.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.online.store.exception.ResourceNotFoundException;
import com.online.store.model.Store;
import com.online.store.repository.StoreRepository;


@RestController
@RequestMapping("/product")
public class StoreController {

    @Autowired
    StoreRepository storeRepository;


    @GetMapping("/stores/price")
    public Store getProductByPrice()throws ResourceNotFoundException {
        return storeRepository.getProductByPrice();
    }
    
    @GetMapping("/stores/size")
    public Store getProductBySize()throws ResourceNotFoundException {
        return storeRepository.getProductBySize();
    }
    
    @GetMapping("/stores/color")
    public Store getProductByColor()throws ResourceNotFoundException {
        return storeRepository.getProductByColor();
    }

}
