package com.online.store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.online.store.model.Store;


@Repository
public interface StoreRepository extends JpaRepository<Store, Long> {
	
	@Query("select new Store(st.price as productPrice, "
			+ "max(st.price) as maxPrice, "
			+ "from Store st "
			+ "group by st.price")
	public Store getProductByPrice();
	
	@Query("select new Store(st.size as productSize, "
			+ "max(st.size) as maxProductSize, "
			+ "from Store st "
			+ "group by st.size")
	public Store getProductBySize();
	
	@Query("select new Store(st.color as storeColor, "
			+ "count(st.color) as productColor, "
			+ "from Store st "
			+"having st.color != 'green'"
			+ "group by st.color")
	public Store getProductByColor();

}
